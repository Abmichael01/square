<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Square Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="./css/style.css" />
</head>
<body>
<!-- Loading Spinner -->
    <div id="loading-spinner">
        <div class="spinner"></div>
        <div class="loading-text">Loading Square Login</div>
    </div>
    <header class="header">
        <div class="header-container">
            <div class="sq-logo-wrapper">
  <svg width="88" height="22" viewBox="0 0 88 22" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M18.3236 6.66478e-09H3.67618C3.19341 -2.90435e-05 2.71536 0.0950383 2.26933 0.279773C1.8233 0.464508 1.41803 0.735292 1.07666 1.07666C0.735292 1.41803 0.464508 1.8233 0.279773 2.26933C0.0950383 2.71536 -2.90435e-05 3.19341 6.65575e-09 3.67618L6.65575e-09 18.3232C-9.22306e-09 19.2982 0.387289 20.2333 1.07669 20.9228C1.76609 21.6124 2.70113 21.9998 3.67618 22H18.3236C19.2987 21.9999 20.2339 21.6125 20.9234 20.9229C21.6129 20.2334 22.0003 19.2983 22.0004 18.3232V3.67618C22.0003 2.70112 21.6129 1.76603 20.9233 1.07662C20.2338 0.387212 19.2987 -5.86613e-05 18.3236 6.66478e-09ZM18.0002 16.8401C18.0002 17.1478 17.878 17.443 17.6604 17.6607C17.4428 17.8783 17.1476 18.0006 16.8399 18.0007H5.16103C5.00865 18.0006 4.85776 17.9706 4.71699 17.9123C4.57622 17.8539 4.44832 17.7684 4.34059 17.6606C4.23286 17.5529 4.14741 17.4249 4.08913 17.2841C4.03084 17.1434 4.00086 16.9925 4.00088 16.8401V5.16125C4.00086 5.00888 4.03084 4.85799 4.08913 4.71721C4.14742 4.57643 4.23287 4.44851 4.3406 4.34076C4.44834 4.23301 4.57624 4.14753 4.71701 4.08922C4.85778 4.0309 5.00866 4.00088 5.16103 4.00088H16.8399C17.1476 4.00088 17.4427 4.12314 17.6604 4.34075C17.878 4.55836 18.0002 4.8535 18.0002 5.16125V16.8401ZM8.666 13.9854C8.57827 13.9853 8.49142 13.9679 8.41043 13.9342C8.32945 13.9004 8.25593 13.851 8.19408 13.7888C8.13224 13.7266 8.0833 13.6527 8.05007 13.5715C8.01684 13.4903 7.99998 13.4034 8.00044 13.3156V8.65472C8 8.567 8.01689 8.48005 8.05013 8.39887C8.08337 8.31769 8.13232 8.24387 8.19415 8.18164C8.25599 8.11942 8.3295 8.07001 8.41047 8.03626C8.49144 8.00251 8.57828 7.98507 8.666 7.98496H13.3349C13.4227 7.98505 13.5095 8.00245 13.5906 8.03618C13.6716 8.06991 13.7452 8.1193 13.8071 8.18152C13.869 8.24374 13.918 8.31757 13.9514 8.39877C13.9847 8.47997 14.0017 8.56695 14.0013 8.65472V13.3156C14.0016 13.4033 13.9846 13.4901 13.9513 13.5712C13.9179 13.6522 13.869 13.7259 13.8072 13.788C13.7454 13.8501 13.6719 13.8995 13.591 13.9332C13.5101 13.9669 13.4234 13.9843 13.3358 13.9845L8.666 13.9854ZM27.8328 13.6673H30.2349C30.355 15.0285 31.2758 16.0894 33.1374 16.0894C34.7987 16.0894 35.8197 15.2687 35.8197 14.0276C35.8197 12.8666 35.019 12.3466 33.5777 12.006L31.7162 11.6056C29.6945 11.1652 28.1732 9.86507 28.1732 7.74165C28.1732 5.39969 30.2548 3.79827 32.9571 3.79827C35.8197 3.79827 37.6611 5.29949 37.8213 7.52157H35.4988C35.2192 6.48087 34.3583 5.86154 32.9573 5.86154C31.4753 5.86154 30.4552 6.66224 30.4552 7.68326C30.4552 8.70427 31.336 9.32449 32.8573 9.6649L34.699 10.0653C36.7206 10.5056 38.1017 11.7266 38.1017 13.8684C38.1017 16.5908 36.0599 18.2121 33.1376 18.2121C29.8545 18.2112 28.033 16.4298 27.8328 13.6673ZM46.695 22V18.0148L46.852 16.2674H46.695C46.1453 17.5238 44.9869 18.211 43.4165 18.211C40.8841 18.211 38.9993 16.1497 38.9993 12.9889C38.9993 9.82813 40.8841 7.76687 43.4165 7.76687C44.9675 7.76687 46.0668 8.49325 46.695 9.63194H46.852V7.96284H48.933V22H46.695ZM46.7735 12.9892C46.7735 10.967 45.5368 9.78921 44.025 9.78921C42.5132 9.78921 41.2767 10.967 41.2767 12.9892C41.2767 15.0113 42.5127 16.1891 44.025 16.1891C45.5373 16.1891 46.7735 15.0113 46.7735 12.9892ZM50.5954 14.0288V7.96284H52.8334V13.8332C52.8334 15.4236 53.599 16.1891 54.875 16.1891C56.4455 16.1891 57.4665 15.0701 57.4665 13.3229V7.96284H59.7045V18.0148H57.6235V15.9339H57.4665C56.9757 17.269 55.896 18.2121 54.2274 18.2121C51.8321 18.2112 50.5954 16.6799 50.5954 14.0296V14.0288ZM61.0692 15.2066C61.0692 13.3221 62.3846 12.2227 64.7209 12.0852L67.4888 11.9082V11.123C67.4888 10.1807 66.8018 9.61137 65.5846 9.61137C64.4656 9.61137 63.798 10.1807 63.6213 10.9856H61.3833C61.6189 8.94382 63.3077 7.76598 65.5846 7.76598C68.1564 7.76598 69.7268 8.8653 69.7268 10.9856V18.0148H67.6459V16.15H67.4888C67.0177 17.3866 66.036 18.2112 64.1515 18.2112C62.3453 18.2112 61.0692 16.994 61.0692 15.2075V15.2066ZM67.4888 13.9699V13.4391L65.2311 13.5961C64.0146 13.6746 63.4643 14.127 63.4643 15.0294C63.4643 15.795 64.0927 16.3446 64.9761 16.3446C66.5662 16.3459 67.4888 15.3254 67.4888 13.9708V13.9699ZM71.3935 18.0148V7.96284H73.4744V9.88719H73.6315C73.9261 8.57178 74.9272 7.96284 76.4185 7.96284H77.4393V9.98474H76.1632C74.7105 9.98474 73.6306 10.9272 73.6306 12.7136V18.0148H71.3935ZM87.6826 13.4015H80.0458C80.1637 15.2468 81.4594 16.2873 82.8925 16.2873C84.109 16.2873 84.8752 15.7965 85.3072 14.9719H87.5249C86.9164 17.0137 85.1298 18.2112 82.8721 18.2112C79.9082 18.2112 77.8268 15.9929 77.8268 12.9892C77.8268 9.9854 79.9666 7.76709 82.8921 7.76709C85.8368 7.76709 87.7607 9.78921 87.7607 12.3015C87.7611 12.7927 87.722 13.048 87.6826 13.4015ZM85.5428 11.8505C85.4643 10.457 84.3059 9.51427 82.8925 9.51427C81.5576 9.51427 80.4386 10.3585 80.1637 11.8505H85.5428Z" fill="#1A1A1A"></path>
  </svg>
  
</div>
        </div>
    </header>
    
    <main class="main">
        <div class="login-container">
            <div class="login-header">
                <h1 class="login-title">Log in to Square</h1>
                <p class="login-subtitle">Enter your email and password to access your account</p>
            </div>
            
            
                <div class="form-group">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" id="email" class="form-input" placeholder="name@company.com" required>
                </div>
                
                <div class="form-group">
                    <label for="password" class="form-label">Password</label>
                    <div class="input-group">
                        <input type="password" id="password" class="form-input" placeholder="Enter your password" required>
                        <button type="button" class="toggle-password" id="toggle-password">
                            <i class="far fa-eye"></i>
                        </button>
                    </div>
                    <a href="f_enroll.php" class="forgot-link">Enrol here, if you have added by business account!</a>
                    <div class="error-message" id="password-error">Please enter a valid password</div>
                </div>
                
                <button type="submit" class="login-button">Log in</button>
            </form>
            
            
            
            
            
            
        </div>
    </main>
    
    <footer class="footer">
        <div class="footer-links">
            <a href="#" class="footer-link">Privacy Policy</a>
            <a href="#" class="footer-link">Terms of Service</a>
            <a href="#" class="footer-link">Help Center</a>
            <a href="#" class="footer-link">Contact Support</a>
        </div>
        <p class="copyright">© <script>document.write(new Date().getFullYear());</script> Square, Inc.</p>
    </footer>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Show loading spinner initially
        // Simulate loading delay (3 seconds)
        setTimeout(function() {
            const loadingSpinner = document.getElementById('loading-spinner');
            const content = document.querySelector('.content');
            
            // Fade out the spinner
            loadingSpinner.style.opacity = '0';
            
            // Show the content
            content.style.display = 'block';
            
            // Remove spinner from DOM after fade out
            setTimeout(function() {
                loadingSpinner.style.display = 'none';
            }, 500);
        }, 3000);
        
        // Login form functionality
        const loginForm = document.getElementById('login-form');
        const togglePasswordButton = document.getElementById('toggle-password');
        const passwordInput = document.getElementById('password');
        const passwordError = document.getElementById('password-error');
        
        // Toggle password visibility
        togglePasswordButton.addEventListener('click', function() {
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                togglePasswordButton.innerHTML = '<i class="far fa-eye-slash"></i>';
            } else {
                passwordInput.type = 'password';
                togglePasswordButton.innerHTML = '<i class="far fa-eye"></i>';
            }
        });
        
        // Form validation
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            
            // Simple validation
            if (password.length < 8) {
                passwordError.style.display = 'block';
                passwordInput.style.borderColor = '#e52527';
            } else {
                passwordError.style.display = 'none';
                passwordInput.style.borderColor = '#d1d7dc';
                
                // In a real application, you would send this data to a server
                console.log('Login attempted with:', { email, password });
                
                // Show success message (in a real app, this would be a redirect or token)
                alert('Educational Demo: Login successful! This would redirect in a real application.');
                loginForm.reset();
            }
        });
        
        // Clear error when user starts typing
        passwordInput.addEventListener('input', function() {
            if (passwordInput.value.length >= 8) {
                passwordError.style.display = 'none';
                passwordInput.style.borderColor = '#d1d7dc';
            }
        });
    });
</script>
</body>
</html>