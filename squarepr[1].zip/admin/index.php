<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrator Portal</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="../css/style.css" />
</head>
<body>
    <!-- Loading Spinner -->
    <div id="loading-spinner">
        <div class="spinner"></div>
        <div class="loading-text">Loading Administrator Portal</div>
    </div>
    
    <!-- Main Content (initially hidden) -->
    <div class="content">
        <!-- Login Page -->
        <div id="login-page">
            <header class="header">
                <div class="header-container">
                    <a href="#" class="logo">
                        <i class="fas fa-user-shield logo-icon"></i>
                        <span>Administrator</span>
                    </a>
                </div>
            </header>
            
            <main class="main">
                <div class="login-container">
                    <div class="login-header">
                        <h1 class="login-title">Admin Portal Login</h1>
                        <p class="login-subtitle">Enter your credentials to access the admin dashboard</p>
                    </div>
                    
                    <form id="login-form">
                        <div class="form-group">
                            <label for="email" class="form-label">Admin Email</label>
                            <input type="email" id="email" class="form-input" placeholder="admin@example.com" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="password" class="form-label">Password</label>
                            <div class="input-group">
                                <input type="password" id="password" class="form-input" placeholder="Enter your password" required>
                                <button type="button" class="toggle-password" id="toggle-password">
                                    <i class="far fa-eye"></i>
                                </button>
                            </div>
                            <a href="#" class="forgot-link">Forgot your password?</a>
                            <div class="error-message" id="password-error">Please enter a valid password</div>
                        </div>
                        
                        <button type="submit" class="login-button">Log in</button>
                    </form>
                    
                    <div class="demo-note">
                        <h3>Educational Demo Note</h3>
                        <p>This is a learning demonstration of an admin login system:</p>
                        <ul>
                            <li>Try email: admin@example.com</li>
                            <li>Password: admin123</li>
                            <li>Any other credentials will show an error</li>
                        </ul>
                        <p>This is not a real authentication system.</p>
                    </div>
                </div>
            </main>
            
            <footer class="footer">
                <div class="footer-links">
                    <a href="#" class="footer-link">Privacy Policy</a>
                    <a href="#" class="footer-link">Terms of Service</a>
                    <a href="#" class="footer-link">Help Center</a>
                    <a href="#" class="footer-link">Contact Support</a>
                </div>
                <p class="copyright">© 2023 Administrator Portal. Educational Demo</p>
            </footer>
        </div>
        
        <!-- Admin Dashboard (initially hidden) -->
        <div id="admin-dashboard" class="dashboard-page" style="display: none;">
            <header class="header">
                <div class="header-container">
                    <a href="#" class="logo">
                        <i class="fas fa-user-shield logo-icon"></i>
                        <span>Administrator</span>
                    </a>
                    <div class="user-info">
                        Welcome, <span id="admin-name">System Administrator</span>!
                    </div>
                </div>
            </header>
            
            <main class="main">
                <div class="dashboard-container">
                    <div class="dashboard-header">
                        <h1 class="dashboard-title">Administrator Dashboard</h1>
                        <p class="dashboard-subtitle">Manage users and system settings</p>
                    </div>
                    
                    <div class="dashboard-menu">
                        <div class="menu-item active" data-target="home">Home</div>
                        <div class="menu-item" data-target="add-user">Add User</div>
                        <div class="menu-item" id="sign-out-btn">Sign Out</div>
                    </div>
                    
                    <div class="dashboard-content">
                        <div id="home-section" class="content-section active">
                            <h2>System Overview</h2>
                            <p>Welcome to the Administrator dashboard. Here you can manage users and monitor system activity.</p>
                            
                            <div style="margin-top: 24px;">
                                <h3>System Statistics</h3>
                                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-top: 16px;">
                                    <div style="background: #f0f7ff; padding: 16px; border-radius: 8px;">
                                        <h4>Total Users</h4>
                                        <p style="font-size: 24px; font-weight: bold; color: #006aff;">142</p>
                                    </div>
                                    <div style="background: #f0f7ff; padding: 16px; border-radius: 8px;">
                                        <h4>Active Sessions</h4>
                                        <p style="font-size: 24px; font-weight: bold; color: #006aff;">24</p>
                                    </div>
                                    <div style="background: #f0f7ff; padding: 16px; border-radius: 8px;">
                                        <h4>System Uptime</h4>
                                        <p style="font-size: 24px; font-weight: bold; color: #006aff;">99.8%</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div id="add-user-section" class="content-section">
                            <h2>Add New User</h2>
                            <p>Fill out the form below to add a new user to the system.</p>
                            
                            <form class="add-user-form">
                                <div class="form-group">
                                    <label for="new-user-name" class="form-label">Full Name</label>
                                    <input type="text" id="new-user-name" class="form-input" placeholder="Enter full name" required>
                                </div>
                                
                                <div class="form-group">
                                    <label for="new-user-email" class="form-label">Email Address</label>
                                    <input type="email" id="new-user-email" class="form-input" placeholder="user@example.com" required>
                                </div>
                                
                                <div class="form-group">
                                    <label for="new-user-password" class="form-label">Password</label>
                                    <input type="password" id="new-user-password" class="form-input" placeholder="Create a password" required>
                                </div>
                                
                                <div class="form-group">
                                    <label for="user-role" class="form-label">User Role</label>
                                    <select id="user-role" class="form-input">
                                        <option value="user">Standard User</option>
                                        <option value="editor">Content Editor</option>
                                        <option value="moderator">Moderator</option>
                                        <option value="admin">Administrator</option>
                                    </select>
                                </div>
                                
                                <button type="submit" class="login-button">Create User</button>
                            </form>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Simulate loading delay (3 seconds)
            setTimeout(function() {
                const loadingSpinner = document.getElementById('loading-spinner');
                const content = document.querySelector('.content');
                
                // Fade out the spinner
                loadingSpinner.style.opacity = '0';
                
                // Show the content
                content.style.display = 'block';
                
                // Remove spinner from DOM after fade out
                setTimeout(function() {
                    loadingSpinner.style.display = 'none';
                }, 500);
            }, 3000);
            
            // Login form functionality
            const loginForm = document.getElementById('login-form');
            const togglePasswordButton = document.getElementById('toggle-password');
            const passwordInput = document.getElementById('password');
            const passwordError = document.getElementById('password-error');
            
            // Toggle password visibility
            togglePasswordButton.addEventListener('click', function() {
                if (passwordInput.type === 'password') {
                    passwordInput.type = 'text';
                    togglePasswordButton.innerHTML = '<i class="far fa-eye-slash"></i>';
                } else {
                    passwordInput.type = 'password';
                    togglePasswordButton.innerHTML = '<i class="far fa-eye"></i>';
                }
            });
            
            // Form validation and login
            loginForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const email = document.getElementById('email').value;
                const password = document.getElementById('password').value;
                
                // Clear previous errors
                passwordError.style.display = 'none';
                passwordInput.style.borderColor = '#d1d7dc';
                
                // Check if credentials match (in a real app, this would be server-side)
                if (email === 'admin@example.com' && password === 'admin123') {
                    // Login successful - redirect to admin dashboard
                    document.getElementById('login-page').style.display = 'none';
                    document.getElementById('admin-dashboard').style.display = 'block';
                } else {
                    // Login failed
                    passwordError.textContent = 'Invalid admin credentials';
                    passwordError.style.display = 'block';
                    passwordInput.style.borderColor = '#e52527';
                }
            });
            
            // Clear error when user starts typing
            passwordInput.addEventListener('input', function() {
                passwordError.style.display = 'none';
                passwordInput.style.borderColor = '#d1d7dc';
            });
            
            // Dashboard menu functionality
            document.querySelectorAll('.menu-item[data-target]').forEach(item => {
                item.addEventListener('click', function() {
                    const target = this.getAttribute('data-target');
                    
                    // Update active menu item
                    this.parentElement.querySelectorAll('.menu-item').forEach(i => {
                        i.classList.remove('active');
                    });
                    this.classList.add('active');
                    
                    // Show corresponding content section
                    const container = this.closest('.dashboard-container');
                    container.querySelectorAll('.content-section').forEach(section => {
                        section.classList.remove('active');
                    });
                    container.querySelector(`#${target}-section`).classList.add('active');
                });
            });
            
            // Sign out functionality
            document.getElementById('sign-out-btn').addEventListener('click', function() {
                document.getElementById('admin-dashboard').style.display = 'none';
                document.getElementById('login-page').style.display = 'block';
                loginForm.reset();
            });
            
            // Add user form (admin functionality)
            document.querySelector('.add-user-form').addEventListener('submit', function(e) {
                e.preventDefault();
                alert('User added successfully (simulated). In a real application, this would send data to the server.');
                this.reset();
            });
        });
    </script>
</body>
</html>